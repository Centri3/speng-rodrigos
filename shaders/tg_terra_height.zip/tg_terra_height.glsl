#include "tg_rmr.glh" 
 
#ifdef _FRAGMENT_

//-----------------------------------------------------------------------------

//	RODRIGO - SMALL CHANGES TO RIVERS AND RIFTS
// Modified Rodrigo's rivers

void    _PseudoRivers(vec3 point, float global, float damping, inout float height)
{
    noiseOctaves = 8.0;
        noiseH       = 1.0;
        noiseLacunarity = 2.1;
	float _seaLevel = seaLevel;
       
    vec3 p = point * 2.0* mainFreq + Randomize;
    vec3 distort = 0.325 * Fbm3D(p * riversSin);
    distort = 0.65 * Fbm3D(p * riversSin) +
                  0.03 * Fbm3D(p * riversSin * 5.0) + 0.01* RidgedMultifractalErodedDetail(point * 0.3* (canyonsFreq+1000)*(0.5*(1/montesSpiky+1))  + Randomize, 8.0, erosion, 2);


    vec2 cell = 2.5 * Cell3Noise2(riversFreq * p + 0.5*distort); //(2.5*height) * Cell3Noise2(riversFreq * p + 0.5*distort);
     
    float errorcor = 0;  //Correct Rivers on marine planets pow(0.985, (1 / seaLevel));

	if (_seaLevel >= 0.0 && _seaLevel < 0.2)    //better correction somehow
		{
			errorcor = -20 * (_seaLevel * _seaLevel) + 9 *_seaLevel;
		}
	if (_seaLevel >= 0.2)
		{
			errorcor = 1.0;
		}

	
	//float adjust = pow(0.992, (height))*0 +1;
	
    float valleys = 1.0 - (saturate((0.36) * abs(cell.y - cell.x) * riversMagn)); //1 - (saturate(0.36 * abs(cell.y - cell.x) * riversMagn))
    valleys = smoothstep(0.0, 1.0, valleys) * damping;
    height = mix(height, _seaLevel - 0.02 + errorcor*0.08, valleys); //.019 .042 .03  _seaLevel - 0.019 + errorcor*0.082, valleys)


    float rivers = 1.0 - (saturate(6.5 * abs(cell.y - cell.x) * riversMagn));
    rivers = smoothstep(0.0, 1.0, rivers) * damping;
    height = mix(height, _seaLevel - 0.04 + errorcor*0.092, rivers); //.004  .052  .015  _seaLevel - 0.04 + errorcor*0.092
}

//-----------------------------------------------------------------------------
// Modified Rodrigo's rifts

void    _Rifts(vec3 point, float damping, inout float height)
{
    float _seaLevel = seaLevel;
	float riftsBottom = _seaLevel;   //float riftsBottom = _seaLevel;

    noiseOctaves    = 6.6;
    noiseH          = 1.0;
    noiseLacunarity = 4.0;
    noiseOffset     = 0.95;

    // 2 slightly different octaves to make ridges inside rifts
    vec3 p = point * 0.12;
    float rifts = 0.0;
    for (int i=0; i<2; i++)
    {
        vec3  distort = 0.5 * Fbm3D(p * riftsSin)+ 0.1 * Fbm3D(p*3 * riftsSin);;
        vec2  cell = Cell3Noise2(riftsFreq * p + distort);
        float width = 0.8*riftsMagn * abs(cell.y - cell.x);
        rifts = softExpMaxMin(rifts, 1.0 - 2.75 * width, 32.0);
        p *= 1.02;
    }

    float riftsModulate = smoothstep(-0.1, 0.2, Fbm(point * 2.3 + Randomize));
    rifts = smoothstep(0.0,1.0, rifts * riftsModulate) * damping;

    height = mix(height, riftsBottom, rifts);

    // Slope modulation
    if (rifts > 0.0)
    {
        float slope = smoothstep(0.1, 0.9, 1.0 - 2.0 * abs(rifts * 0.35 - 0.5));
        float slopeMod = 0.5*slope * RidgedMultifractalErodedDetail(point * 5.0 * canyonsFreq + Randomize, 8.0, erosion, 8.0);
        slopeMod *= 0.05*riftsModulate;
        height = softExpMaxMin(height - slopeMod, riftsBottom, 75.0);
    }
}

//-----------------------------------------------------------------------------


void    HeightMapTerra(vec3 point, out vec4 HeightBiomeMap)
{
    // Assign a climate type
    noiseOctaves    = (oceanType == 1.0) ? 5.0 : 12.0; // Reduce terrain octaves on oceanic planets (oceanType == 1)
    noiseH          = 0.5;
    noiseLacunarity = 2.218281828459;
    noiseOffset     = 0.8;
    float climate, latitude;
    if (tidalLock <= 0.0)
    {
        latitude = abs(point.y);
        latitude += 0.15 * (Fbm(point * 0.7 + Randomize) - 1.0);
        latitude = saturate(latitude);
        if (latitude < latTropic - tropicWidth)
            climate = mix(climateTropic, climateEquator, (latTropic - tropicWidth - latitude) / latTropic);
        else if (latitude > latTropic + tropicWidth)
            climate = mix(climateTropic, climatePole, (latitude - latTropic - tropicWidth) / (1.0 - latTropic));
        else
            climate = climateTropic;
    }
    else
    {
        latitude = 1.0 - point.x;
        latitude += 0.15 * (Fbm(point * 0.7 + Randomize) - 1.0);
        climate = mix(climateTropic, climatePole, saturate(latitude));
    }

    // Litosphere cells
    //float lithoCells = LithoCellsNoise(point, climate, 1.5);

    // Global landscape
    vec3 p = point * mainFreq + Randomize;
    noiseOctaves = 5;
    vec3  distort = 0.35 * Fbm3D(p * 0.73);
    noiseOctaves = 4;
    distort += 0.005 * (1.0 - abs(Fbm3D(p * 132.3)));
    float global = 1- Cell3Noise(p + distort);
	

//	float global =
//      1.0 - smoothstep(0.0, 1.0,
//                       iqTurbulence(p + distort + Randomize,
//                                    0.5 + smoothstep(0.1, 0.0, colorDistMagn) * 0.2));
//									
    // Make sea bottom more flat; shallow seas resembles those on Titan;
    // but this shrinks out continents, so value larger than 1.5 is unwanted
    global = softPolyMax(global, 0.0, 0.1);
    global = pow(global, 1.5);


    // Venus-like structure
    float venus = 0.0;
    
          noiseOctaves = 4;
        distort = Fbm3D(point * 0.3) * 1.5;
        noiseOctaves = 6;
       venus = Fbm((point + distort) * venusFreq) * (venusMagn+0.3);

float _seaLevel = seaLevel;
/* float seaDepth = -5*seaLevel + 1;
float oceanScale = 0;

if (seaLevel >= 0.2)
{
	seaDepth = 0;
} 

if (oceanType > 0)
{
	oceanScale = (2 * latitude - 1) * seaDepth * (2.326 * tropicWidth - 0.163);
	
	if (oceanScale <= (-1*seaLevel-0.1))
	{
		oceanScale = -seaLevel-0.1;
	}
	_seaLevel = _seaLevel - oceanScale;
}
*/   

    global = (global + venus - _seaLevel) * 0.5 + _seaLevel;
    float shore = saturate(70.0 * (global - _seaLevel));

    // Biome domains
    noiseOctaves = 6;
    vec3  pb = p * 2.3 + 0.5 * Fbm3D(p * 1.5);
    vec4  col;
    vec2  cell = Cell3Noise2Color(pb, col);
    float biome = col.r;
    float biomeScale = saturate(2.0 * (pow(abs(cell.y - cell.x), 0.7) - 0.05));
    float terrace = col.g;
    float terraceLayers = max(col.b * 10.0 + 3.0, 3.0);
    terraceLayers += Fbm(pb * 5.41);

    float montRange = saturate(DistNoise(point * 22.6 + Randomize, 2.5) + 0.5);
    montRange *= montRange;
    float montBiomeScale = min(pow(2.2 * biomeScale, 3.5), 1.0) * montRange;

    float inv2montesSpiky = 1.0 / (montesSpiky * montesSpiky);
    float heightD  = 0.0;
    float height   = 0.0;
    float landform = 0.0;
    float dist;
//	RODRIGO 

float _hillsFreqq = hillsFreq;

if (riversMagn > 0.0 && cracksOctaves == 0 && texScale > 8200 && SEversion == 1)// || riversMagn == 0.0 && cracksOctaves > 0)   // exclude icy and small planets
	{
		_hillsFreqq = hillsFreq*5;
	}

	else if (riversMagn == 0.0 && cracksOctaves > 0 && oceanType < 0.5)
		{
			_hillsFreqq = hillsFreq*(1 - volcanoActivity / 6) *3;
		}

	else if (riversMagn > 0.0 && cracksOctaves > 0 && texScale > 8200)
		{
			_hillsFreqq = hillsFreq *(1 - volcanoActivity / 4);
		}

float hillsMagnn = hillsMagn;

if (hillsMagn < 0.1)   // Fix to spiky terrain before planet melts
	{
		hillsMagnn = 0.1;
	}
	else
		{
			hillsMagnn = hillsMagn;
		}

noiseOctaves = 8;
vec3  pp = (point + Randomize) * (0.0005 * _hillsFreqq / (hillsMagnn * hillsMagnn));

noiseOctaves = 12.0;
distort = Fbm3D((point + Randomize) * 0.07) * 1.5;

noiseOctaves = 10.0;
noiseH       = 1.0;
noiseLacunarity = 2.3;
noiseOffset  = montesSpiky;
float rocks = -0.005 * iqTurbulence(point * 20.0, 1.0);  //-0.005 * iqTurbulence(point * 200.0, 1.0);
 
//small terrain elevations   
noiseOctaves = 12.0;
    distort = Fbm3D((point + Randomize) * 0.07) * 1.5;
    noiseOctaves = 8.0;

float fr = 0.20 * (1.5 - RidgedMultifractal(pp,         2.0)) +
               0.05 * (1.5 - RidgedMultifractal(pp * 10.0,  2.0)) + rocks * 0.3; //* smoothstep(2, 1, volcanoActivity)


fr *= 1 - smoothstep(0.0, 0.02, _seaLevel-global);



global =  mix(global,global+0.2,fr);


//Mesas
float zr = 1.0 + 2*Fbm(point + distort) + 7 * (1.5 - RidgedMultifractalEroded(pp * 0.8, 8.0, erosion)) - 6 * (1.5 - RidgedMultifractalEroded(pp * 0.1,  8.0,erosion))- 0.01 * (1.5 - RidgedMultifractalEroded(pp * 4,  8.0,erosion));

zr = smoothstep(0.0, 1.0, 0.2*zr*zr);
zr *= 1 - smoothstep(0.0, 0.02, _seaLevel-global);
zr = 0.1*_hillsFreqq* smoothstep(0.0, 1.0, zr);
global =  mix(global,global+0.0006,zr);

noiseOctaves = 10.0;
        noiseH       = 1.0;
        noiseLacunarity = 2.3;
        noiseOffset  = montesSpiky;
        float rr  = 0.3*((0.15 * iqTurbulence(point * 0.4 * montesFreq +Randomize, 0.45)) * (RidgedMultifractalDetail(point * point * montesFreq *0.8+ venus + Randomize, 1.0, montBiomeScale)));

rr *= 1 - smoothstep(0.0, 0.02, _seaLevel-global);

global += rr;

    // Ice caps
    // Make more steep slope on oceanic planets (oceanType == 0.1) and shallower on earth-like planets (oceanType == 1.0)
    //float oceaniaFade = (oceanType == 1.0) ? 0.2 : 1.0;
    //float iceCap = smoothstep(0.0, 1.0, saturate((latitude / latIceCaps - 1.0) * 50.0 * oceaniaFade));

    // Apply ice caps
    // Suppress everything except ice caps in oceanic planets
    //height = height * oceaniaFade + (_seaLevel + icecapHeight) * iceCap; // old version
	//height = height * oceaniaFade + (0.3 * _seaLevel + icecapHeight) * iceCap; // donatelo version


    if (biome < dunesFraction)
    {
        // Dunes
        noiseOctaves = 2.0;
        dist = dunesFreq + Fbm(p * 1.21);
        float desert = max(Fbm(p * dist), 0.0);
        float dunes  = DunesNoise(point, 3);
        landform = (0.0002 * desert + dunes) * pow(biomeScale, 3);
        heightD += dunesMagn * landform;
    }
    else if (biome < hillsFraction)
    {
		// Mountains
		if (erosion > 0.0)
		{
			noiseOctaves = 10.0;
			noiseH       = 0.90;  // Going to tweak some
			noiseLacunarity = 2.0;
			noiseOffset  = montesSpiky;    // Also caused offset
			height = hillsMagnn * 2.88 * ((1.25 + iqTurbulence(point * 0.5 * _hillsFreqq * inv2montesSpiky * 1.25 + Randomize, 0.55)) * (0.05 * RidgedMultifractalErodedDetail(point * 1.0 * _hillsFreqq * inv2montesSpiky * 1.5 + Randomize, 1.0, erosion, montBiomeScale)));
		}
		else
		{
			noiseOctaves = 10.0;
			noiseH       = 1.0;
			noiseLacunarity = 2.0;
			noiseOffset  = montesSpiky;
			height = hillsMagnn * 7.5 * ((1.25 + iqTurbulence(point * 0.5 * (_hillsFreqq / 2) * inv2montesSpiky * 1.25 + Randomize, 0.55)) * (0.05 * RidgedMultifractalDetail(point * 1.0 * (_hillsFreqq / 2) * inv2montesSpiky * 1.5 + Randomize, 1.0, montBiomeScale)));
		}
    }
    else if (biome < hills2Fraction)
    {
		// "Eroded" hills
		if (erosion > 0.0)    // Causing break in terrain
		{
			noiseOctaves = 10.0;
			noiseH       = 0.90;
			noiseOffset  = montesSpiky;   // you cause it ya little shit
			noiseLacunarity = 2.1;
			height = (0.5 + 0.4 * iqTurbulence(point * 1.12 * _hillsFreqq + Randomize, 0.55)) * (montBiomeScale * hillsMagnn * (0.05 - (0.4 * RidgedMultifractalDetail(point * _hillsFreqq + Randomize, 2.0, venus)) + 0.3 * RidgedMultifractalErodedDetail(point * _hillsFreqq + Randomize, 2.0, 1.1 * erosion, montBiomeScale)));
		}
		else
		{
			noiseOctaves = 8.0; // Decrease the number of octaves for smoother terrain							//Think I'll add these back in
			noiseLacunarity = 2.0; // Slightly increase lacunarity for more variation in frequency
			//noiseOffset  = venusFreq;
			height = montBiomeScale * hillsMagnn * JordanTurbulence(point * _hillsFreqq + Randomize, 0.7, 0.5, 0.6, 0.35, 1.0, 0.8, 1.0);
		}
    }
    else if (biome < canyonsFraction)
    {
		if (erosion > 0.0)
		{
			// TPE Canyons
			noiseOctaves = 10.0;
			noiseH       = 0.1;
			noiseLacunarity = 2.1;
			noiseOffset  = montesSpiky;
			height = -canyonsMagn * 4 * ((0.5 + 0.8 * iqTurbulence(point * 0.5 * (canyonsFreq * 2) + Randomize, 0.55)) * (0.1 * RidgedMultifractalDetail(point * 0.7 * (canyonsFreq * 2) + Randomize, 1.0, montBiomeScale)));
			// if (terrace < terraceProb)
			{
				terraceLayers *= 5.0;
				float h = height * terraceLayers;
				height = (floor(h) + smoothstep(0.1, 0.9, fract(h))) / terraceLayers;
			}
		}
		else
		{
			// TPE Canyons
			noiseOctaves = 8.0; // Reduced for smoother transitions
			noiseH       = 0.2; // Increased for more variation
			noiseLacunarity = 2.0; // Adjusted for smoother noise
			noiseOffset  = montesSpiky;
			height = -canyonsMagn * ((0.4 + 0.7 * iqTurbulence(point * 0.4 * (canyonsFreq * 2) + Randomize, 0.5)) * (0.08 * RidgedMultifractalDetail(point * 0.6 * (canyonsFreq * 2) + Randomize, 0.9, montBiomeScale)));
			//if (terrace < terraceProb)
			{
 			   //terraceLayers *= 4.0; // Adjusted for less abrupt terracing
 			   float h = height * terraceLayers;
 			   height = (floor(h) + smoothstep(0.05, 0.85, fract(h))) / terraceLayers; // Adjusted for smoother terracing
			}
		}
    }
    else
    {
		// Mountains
		if (erosion > 0.0)
		{
			noiseOctaves = 10.0;
			noiseH       = 1.0;
			noiseLacunarity = 2.1;
			noiseOffset  = montesSpiky;
			// height = montesMagn * 5.0 * (0.5 + 0.4 * iqTurbulence(point * 0.5 * montesFreq + Randomize, 0.55))* 0.7* montesMagn * montRange * RidgedMultifractalErodedDetail(point * montesFreq * inv2montesSpiky + Randomize, 2.0, erosion, montBiomeScale)+ 0.6 * biomeScale * hillsMagnn * JordanTurbulence(point/4 * _hillsFreqq/4 + Randomize, 0.8, 0.5, 0.6, 0.35, 1.0, 0.8, 1.0);
			height = (0.5 + 0.4 * iqTurbulence(point * 0.5 * (montesFreq * 3) + Randomize, 0.55)) * 0.4 * montesMagn * 0.8* montRange * RidgedMultifractalErodedDetail(point * (montesFreq * 3) * inv2montesSpiky + Randomize, 2, erosion, montBiomeScale);
		}
		else
		{
			noiseOctaves = 10.0;
			noiseH       = 1.0;
			noiseLacunarity = 2.3;
			noiseOffset  = montesSpiky;
			height = montesMagn * 5.0 * ((0.5 + 0.8 * iqTurbulence(point * 0.5 * montesFreq + Randomize, 0.55)) * (0.1 * RidgedMultifractalDetail(point *  montesFreq + venus + Randomize, 1.0, montBiomeScale)));
		}
    }


    // Mare
//	RODRIGO - Edited Mare. Supress mare in terras
    float mare = global;
    float mareFloor = global;
    float mareSuppress = 1.0;

	if (riversMagn > 0.0)
	{
		mare = global;
	}
	else
	{

    if (mareSqrtDensity > 0.05)
    {
        //noiseOctaves = 2;
        //mareFloor = 0.6 * (1.0 - Cell3Noise(0.3*p));
        noiseH           = 0.5;
        noiseLacunarity  = 2.218281828459;
        noiseOffset      = 0.8;
        craterDistortion = 1.0;
        noiseOctaves     = 6.0;  // Mare roundness distortion
        mare = MareNoise(point, global, 0.0, mareSuppress);
        //lithoCells *= 1.0 - saturate(20.0 * mare);
    }
}


    height *= saturate(20.0 * mare);        // suppress mountains, canyons and hills (but not dunes) inside mare
    height = (height + heightD) * shore;    // suppress all landforms inside seas
    //height *= lithoCells;                 // suppress all landforms inside lava seas

    // Ice caps
    // Make more steep slope on oceanic planets (oceanType == 0.1) and shallower on earth-like planets (oceanType == 1.0)
    float oceaniaFade = (oceanType == 1.0) ? 0.2 : 1.0;
    float iceCap = smoothstep(0.0, 1.0, saturate((latitude / latIceCaps - 1.0) * 50.0 *oceaniaFade));

    // Ice cracks
    float mask = 1.0;
    if (cracksOctaves > 0.0)
    {
        landform = CrackNoise(point, mask) * iceCap;
        height += landform;
    }

    // Craters
    float crater = 0.0;
    if (craterSqrtDensity > 0.05)
    {
        heightFloor = -0.1;
        heightPeak  =  0.6;
        heightRim   =  1.0;
        crater = CraterNoise(point, 0.5 * craterMagn, craterFreq, (craterSqrtDensity * (1 - (volcanoActivity / 2.1))), craterOctaves);  // reduce craters on volcanic worlds Donatelo200 11/16/2025
        noiseOctaves    = 10.0;
        noiseLacunarity = 2.0;
        crater = 0.25 * crater + 0.05 * crater * iqTurbulence(point * montesFreq + Randomize, 0.55);

        // Young terrain - suppress craters
        noiseOctaves = 4.0;
        vec3 youngDistort = Fbm3D((point - Randomize) * 0.07) * 1.1;
        noiseOctaves = 4.0;
        float young = 1.0 - Fbm(point + youngDistort);
        young = smoothstep(0.0, 1.0, young * young * young);
        crater *= young;
    }

    height += mare + crater;

    // Sea bottom
    /*const float seaBottomTranstionStart = 0.0008;
    const float seaBottomTranstionEnd   = 0.0010;
    float depth = height - _seaLevel;*/

    

    //	RODRIGO - Edited Rivers and Rifts. No more inverse rifts on mare

float rodrigoDamping;

rodrigoDamping = global - _seaLevel - rodrigoDamping;
float damping;
float _rodrigoDamping = rodrigoDamping;
    

    // Rifts
    if (riftsMagn > 0.0)
{
damping =    (smoothstep(1.0, 0.1, height - _seaLevel)) *
                        (smoothstep(-0.1, -0.2, _seaLevel - height));

        _Rifts(point, damping, height);
}


    // Shield volcano
    //if (volcanoOctaves > 0 && cracksOctaves > 0)
    //    height = VolcanoNoise(point, global, height);

    // Mountain glaciers
    /*noiseOctaves = 5.0;
    noiseLacunarity = 3.5;
    float vary = Fbm(point * 1700.0 + Randomize);
    float snowLine = (height + 0.25 * vary - snowLevel) / (1.0 - snowLevel);
    height += 0.0005 * smoothstep(0.0, 0.2, snowLine);*/

    // Apply ice caps
    // Suppress everything except ice caps in oceanic planets
    //height = height * oceaniaFade + (_seaLevel + icecapHeight) * iceCap; // old version
	//height = height * oceaniaFade + (0.3 * _seaLevel + icecapHeight) * iceCap; // donatelo version

float _height = height;

//	RODRIGO - Terrain noise matching albedo noise

float _colorDistMagn = colorDistMagn;
float colorDistMin = 0.065;

if (colorDistMagn <= colorDistMin && cracksOctaves >= 0)  // Prevent some planets from becoming chaos
	{
		_colorDistMagn = colorDistMin;
	}

noiseOctaves    = 14.0;
noiseLacunarity = 2.218281828459;
noiseH = 0.55 + smoothstep(0.0, 0.1, _colorDistMagn) * 0.7;
distort = Fbm3D((point + Randomize) * 1.0) * 0.0;   //Fbm3D((point + Randomize) * 0.07) * 1.5  useless terrain elevation imo
float SmallDistort = 0;
if (cracksOctaves > 0) 
	{
		noiseH = 0.6 + smoothstep(0.0, 0.1, _colorDistMagn) * 0.7;;
	}
	
if (cracksOctaves == 0 && volcanoActivity > 1.0)
	{
		distort = (saturate(iqTurbulence(point + Randomize, 0.55) * (2 * (volcanoActivity - 1)))) * (volcanoActivity - 1) + (Fbm3D((point + Randomize) * 0.07) * 0) * (2 - volcanoActivity);  //Io like on atmosphered planets
		SmallDistort = saturate(iqTurbulence(point + Randomize, 0.75) * (2 * (volcanoActivity - 1))) * (volcanoActivity - 1);
	}
	else if (cracksOctaves == 0 && volcanoActivity < 1.0)
	{
			distort = Fbm3D((point + Randomize) * 0.07) * 0;  //Normal non-volcanic (also useless noise but shader breaks if removed
	}
	
	else if (cracksOctaves > 0) //&& riversMagn == 0)
	{
	
		distort =Fbm3D((point * 0.26 + Randomize) * (volcanoActivity/2+1)) * (1.5 + venusMagn ) + saturate(iqTurbulence(point + Randomize, 0.15) * volcanoActivity);
	}

float vary = 1.0 - 5*(Fbm((point + distort + (SmallDistort * 0.02)) * (1.5 - RidgedMultifractal(pp, 8.0)+ RidgedMultifractal(pp*0.999, 8.0))));  // + (SmallDistort * 0.015)
//float smallvary = 1.0 - 0.15*(Fbm((point + SmallDistort) * (1.5 - RidgedMultifractal(pp, 8.0)+ RidgedMultifractal(pp*0.999, 8.0))));
//vary *= 0.5 * vary * vary;	

if (oceanType > 0.5)  
  {
    height = mix(height, height, vary) - _seaLevel;
  }

if (cracksOctaves > 0)  
  {
    height = mix(height, height + 0.1, vary) - 0.1;
  } 
  
  else   
  {
  height = mix(height, height + 0.05, vary) - 0.05;    //0.0015
 
  }


// Pseudo rivers

if (riversMagn > 0.0)
    {	
		if (cracksOctaves > 0)
		{
			rodrigoDamping =  - _seaLevel + global / (1.0 + _seaLevel * 10) - rodrigoDamping + height;  //Dampen rivers under extreme elevations
		}
	//	if (cracksOctaves > 0)
	//	{
	//		rodrigoDamping = height * 1.5 - _seaLevel - rodrigoDamping;  //Dampen rivers under extreme elevations
	//	}
		noiseOctaves = 12.0;
		noiseH       = 0.8;
		noiseLacunarity = 2.3;
		//p = point * 2.0* mainFreq + Randomize;
		//distort = 0.65 * Fbm3D(p * riversSin) + 0.03 * Fbm3D(p * riversSin * 5.0) + 0.01* RidgedMultifractalErodedDetail(point * 0.3* (canyonsFreq+1000)*(0.5*(inv2montesSpiky+1))  + Randomize, 8.0, erosion, montBiomeScale*2);
		//cell = 2.5* Cell3Noise2(riversFreq * p + 0.5*distort);
		/*
		float pseudoRivers2 = 1.0 - (saturate(0.36 * abs(cell.y - cell.x) * riversMagn));
			pseudoRivers2 = smoothstep(0.25, 0.99, pseudoRivers2); 
			pseudoRivers2 *= 1.0 - smoothstep(0.135, 0.145, rodrigoDamping); // disable rivers inside continents
			pseudoRivers2 *= 1.0 - smoothstep(0.000, 0.0001, _seaLevel - height); // disable rivers inside oceans
			height = mix(height, _seaLevel+0.003, pseudoRivers2);
			cell = 2.5* Cell3Noise2(riversFreq * p + 0.5*distort);
		float PseudoRivers = 1.0 - (saturate(2.8 * abs(cell.y - cell.x) * riversMagn));
			PseudoRivers = smoothstep(0.0, 1.0, PseudoRivers); 
			PseudoRivers *= 1.0 - smoothstep(0.055, 0.057, global-_seaLevel);
			PseudoRivers *= 1.0 - smoothstep(0.00, 0.005, _seaLevel - height); // disable rivers inside oceans
			height = mix(height, _seaLevel-0.0035, PseudoRivers);
		*/
        damping = (smoothstep(0.185, 0.135, rodrigoDamping)) *    // disable rivers inside continents smoothstep(0.145, 0.135, rodrigoDamping)  smoothstep(0.185, 0.135, rodrigoDamping)
            (smoothstep(0.08, -0.018 - pow(0.99, (1 / _seaLevel)) * 0.14, _seaLevel - height));  // disable rivers inside oceans
			
		_PseudoRivers(point, global, damping, height);
	}

	// Shield volcano
    if (volcanoOctaves > 0) //&& cracksOctaves == 0)
        height = _VolcanoNoise(point, global, height);

    // Apply ice caps
    // Suppress everything except ice caps in oceanic planets
    //height = height * oceaniaFade + (_seaLevel + icecapHeight) * iceCap; // old version  smoothstep(0.0, 1.0, saturate((latitude / latIceCaps - 1.0)
	height = height + (0.3 * _seaLevel + icecapHeight) * iceCap; // donatelo version

	// smoothly limit the height
	height = softPolyMin(height, 1.0, 0.3);
	height = softPolyMax(height, 0.0, 0.3);

	if ((cracksOctaves == 0 || volcanoTemp >= 0.75) && lavaCoverage > 0 && oceanType == 0)   //((volcanoTemp > 0.7 || hillsMagn <=0.05) && lavaCoverage > 0 && oceanType == 0)
	{
	height = height-log(1.2*lavaCoverage+1);  //log(9*lavaCoverage+1)
	if (height <0.0002)
	{
		height = 0;
	}
	
	}


    if (oceanType > 0.5)  
	{
		height = softPolyMin(height, 0.01, 0.5);
		height = softPolyMax(height, 0.0, 0.3);
	}
	
	


	
if (riversMagn > 0.0)
{
    HeightBiomeMap = vec4(height-0.06);
}

else
{
HeightBiomeMap = vec4(height);
}


}

//-----------------------------------------------------------------------------

void main()
{
    vec3  point = GetSurfacePoint();
    HeightMapTerra(point, OutColor);
}

//-----------------------------------------------------------------------------

#endif

